#include<stdio.h>
int main()
{
	char s1[10],s2[10],s3[10],s4[10],s5[10];
	char blank[10];
	
}
